# Satistuffed

Go is training for go, let's go.

```
make init
```

```
make up
```